package lab10Serializacja;

public class ObjectInsideObject {
    String objData = "some object that has other inside";
    SimpleObject so = new SimpleObject(55, "Insider");
}
