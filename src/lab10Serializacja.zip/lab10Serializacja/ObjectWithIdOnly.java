package lab10Serializacja;

public class ObjectWithIdOnly {
    int id;
}
